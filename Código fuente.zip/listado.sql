create database listado;
use listado;

create table usuarios (
	doc_user integer (15),
	nom_user varchar (50),
	usu_user varchar (20),
	contraseña varchar (15),
	primary key (doc_user)
);

create table cursos (
	id_curso int auto_increment,
    grupo integer (10),
	materia varchar (30),
    doc_user integer (15),
	primary key (id_curso),
	foreign key (doc_user) references usuarios (doc_user)
);

insert into cursos values ("","506","Matemáticas","1000518285");
SELECT * FROM cursos;

create table alumnos(
	id_alumno int auto_increment,
	doc_alumno integer (15),
	apellido varchar (30),
	nombre varchar (30),
	fecha varchar (10),
	genero enum ("M","F"),
	correo varchar (30),
	celular varchar (20),
	comentario varchar (500),
    id_curso integer (10),
	primary key (id_alumno),
	foreign key (id_curso) references cursos (id_curso)
);

select * from alumnos;

create table listas (
	id int auto_increment,
    fecha date,
    asistencia enum ("A","R","FJ","FI"),
	id_alumno integer (15),
    primary key (id),
    foreign key (id_alumno) references alumnos (id_alumno)
);

select CASE asistencia
    WHEN 'A' THEN 'Asistencias'
    WHEN 'R' THEN 'Retrasos'
    WHEN 'FJ' THEN 'Fallas justificadas'
	WHEN 'FI' THEN 'Fallas injustificadas'
    ELSE 'Otro Estado'
	END AS tipo, count(*) as cantidad from listas where id_alumno = "1" and fecha BETWEEN '2023-12-14' AND '2023-12-28' group by asistencia;

select * from listas;
drop table listas;

insert into usuarios values ("1000518285","John Beltran","Beltran10", "123");
UPDATE usuarios SET contraseña = '123'  WHERE doc_user = '1000518285' and usu_user = 'Beltran10';

select * from usuarios;

select doc_user, nom_user, usu_user, contraseña from usuarios where usu_user = "Beltran10" and contraseña = "ABC12345"; 

select CASE asistencia
    WHEN 'A' THEN 'Asistencias'
    WHEN 'R' THEN 'Retrasos'
    WHEN 'FJ' THEN 'Fallas justificadas'
	WHEN 'FI' THEN 'Fallas injustificadas'
    ELSE 'Otro Estado'
	END AS tipo, count(*) as cantidad, nombre, apellido from listas inner join alumnos ON listas.id_alumno = alumnos.id_alumno where alumnos.doc_alumno = "1000518285" and listas.fecha BETWEEN '2023-12-14' AND '2023-12-28' group by asistencia;
    
    select*from alumnos;
    
    select CASE genero
    WHEN 'F' THEN 'Niñas'
    WHEN 'M' THEN 'Niños'
    ELSE 'Otro'
	END AS genero, count(*) as cantidad, sum(id_alumno) as num_alu from alumnos inner join cursos ON cursos.id_curso = alumnos.id_curso where alumnos.id_curso = "1" group by genero;
    
    
