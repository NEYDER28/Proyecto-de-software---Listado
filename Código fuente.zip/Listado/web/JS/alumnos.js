  function mostrarModal() {
    var modal = document.getElementById('modal');
    modal.style.display = 'flex';
  }

  function cerrarModal() {
    var modal = document.getElementById('modal');
    modal.style.display = 'none';
  }

  function crearCurso() {
    var grupo = document.getElementById('grupo').value;
    var materia = document.getElementById('materia').value;

    // Crear un nuevo elemento de botón para mostrar el curso
    var cursoButton = document.createElement('button1');
    cursoButton.innerHTML = 'Grupo: ' + grupo + ' - Materia: ' + materia;

    // Agregar el nuevo botón al contenedor
    var cursosContainer = document.getElementById('cursosContainer');
    cursosContainer.appendChild(cursoButton);

    // Cerrar la ventana emergente después de hacer clic en "Crear"
    cerrarModal();
  }
  
 