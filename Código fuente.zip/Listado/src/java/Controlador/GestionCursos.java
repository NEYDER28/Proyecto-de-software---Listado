/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Cursos;
import Modelo.Modelo_Cursos;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

@WebServlet(name = "GestionCursos", urlPatterns = {"/GestionCursos"})
public class GestionCursos extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        if (request.getParameter("btnguardar") != null) {
            
                this.insertar(request, response);
            
        }
        
        if (request.getParameter("btactualizar") != null) {
            
                this.editar(request, response);
            
        }
        
        if (request.getParameter("bteliminar") != null) {
            
                this.eliminar(request, response);
            
        }
        
    }
    
    protected void insertar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String c,g,n,d;
                boolean v;
            
                c=null;
                g=request.getParameter("grupo");
                n=request.getParameter("materia");
                d=request.getParameter("docu");
        
            
                Cursos usu=new Cursos(c, g,n,d);
                Modelo_Cursos mc=new Modelo_Cursos();
                v=mc.insertarCursos(usu);
            
                if (v) {
                
                    JOptionPane.showMessageDialog(null, "Datos Guardados");
                    response.sendRedirect("cursos.jsp");
            
                }
            
                else {
            
                    JOptionPane.showMessageDialog(null, "Datos NO guardados");
                    response.sendRedirect("cursos.jsp");
                
                }
        
    }
    
    protected void editar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
                String c,g,n,d;
                boolean v;
            
                c=request.getParameter("codigo");
                g=request.getParameter("grupo");
                n=request.getParameter("materia");
                d=request.getParameter("docu");
            
                Cursos usu=new Cursos(c,g,n,d);
                Modelo_Cursos mc=new Modelo_Cursos();
                v=mc.editar_Cursos(usu);
            
                if (v) {
                
                    JOptionPane.showMessageDialog(null, "Datos modificados");
                    response.sendRedirect("cursos.jsp");
            
                }
            
                else {
            
                    JOptionPane.showMessageDialog(null, "Datos NO modificados");
                    response.sendRedirect("cursos.jsp");
                
                }
        
    }
    
    protected void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
                String c;
                boolean v;
            
                c=request.getParameter("codigo");
               
            
                Cursos usu=new Cursos(c);
                Modelo_Cursos mc=new Modelo_Cursos();
                v=mc.eliminar_Grupos(usu);
            
                if (v) {
                
                    JOptionPane.showMessageDialog(null, "Datos eliminados");
                    response.sendRedirect("cursos.jsp");
            
                }
            
                else {
            
                    JOptionPane.showMessageDialog(null, "El curso tiene registros, No puede eliminar");
                    response.sendRedirect("cursos.jsp");
                
                }
        
    }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}