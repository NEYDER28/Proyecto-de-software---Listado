/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Modelo_Login;
import Modelo.Login2;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

@WebServlet(name = "Login", urlPatterns = {"/Login"})
public class Login_cont extends HttpServlet {
    private String doc, nom, us, cl;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        if (request.getParameter("btniniciar") != null) {
            
                this.logint(request, response);
            
        }
        
    }
    
    protected void logint(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        ArrayList<Login2> dat=new ArrayList();
        
        String u, c;
        boolean v;
            
        u=request.getParameter("user");
        c=request.getParameter("password");
                
                Login2 lis=new Login2();
                Login2 lo=new Login2(u, c);
                Modelo_Login mol=new Modelo_Login();
                dat=mol.login(lo);
        
        if (dat.size()>0) {
                    
            for (int i = 0; i < dat.size(); i++) {
                
                lis=dat.get(i);
                doc=lis.getCedula();
                nom=lis.getNombre();
                us=lis.getUsuario();
                cl=lis.getClave();
                
                
                    
            }
            
            if (us.equals(u) && cl.equals(c)) {

                JOptionPane.showMessageDialog(null, "Bienvenid@"+" "+nom);
                HttpSession ses=request.getSession();
                ses.setAttribute("documento", doc);
                ses.setAttribute("nombre", nom);      
                ses.setAttribute("usuario", us);             
                response.sendRedirect("cursos.jsp");

            }           
            }
            else{
        
            JOptionPane.showMessageDialog(null, "Datos Incorrectos. Intentelo de nuevo");
            HttpSession ses=request.getSession();
            response.sendRedirect("index.jsp");          
        }      
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
