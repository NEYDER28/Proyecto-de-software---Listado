package Modelo;

public class Lista {
    
    private String id_lista;
    private String fecha;
    private String asistencia;
    private String id_alumno;

    public Lista() {
    }

    public Lista(String id_lista, String fecha, String asistencia, String id_alumno) {
        this.id_lista = id_lista;
        this.fecha = fecha;
        this.asistencia = asistencia;
        this.id_alumno = id_alumno;
    }

    public String getId_lista() {
        return id_lista;
    }

    public void setId_lista(String id_lista) {
        this.id_lista = id_lista;
    }
    
        public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    public String getAsistencia() {
        return asistencia;
    }

    public void setAsistencia(String asistencia) {
        this.asistencia = asistencia;
    }
    
        public String getId_alumno() {
        return id_alumno;
    }

    public void setId_alumno(String id_alumno) {
        this.id_alumno = id_alumno;
    }
    
    
}
