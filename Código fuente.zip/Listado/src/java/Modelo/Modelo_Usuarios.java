package Modelo;

import Conexion.conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Modelo_Usuarios {
    
    conexion con=new conexion();
    Connection cnn=con.conexionbd();
    PreparedStatement ps=null;
    ResultSet rs=null;
    
    public ArrayList<Usuarios> consultarusuarios(){
        ArrayList<Usuarios> lista=new ArrayList<>();
      
        try {
            
            ps=cnn.prepareStatement("SELECT * FROM usuarios");
            rs=ps.executeQuery();
            
            while (rs.next()){
            
                Usuarios cli=new Usuarios(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
                lista.add(cli);
                
            }
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, ex);
            
        }
        
    return lista;
       
   }
    
    public int insertarusuario(Usuarios us){
        
        int respuesta=0;
                
        try {
            
                  
            ps=cnn.prepareStatement("INSERT INTO usuarios VALUES(?,?,?,?)");
            ps.setString(1, us.getCedula());
            ps.setString(2, us.getNombre());
            ps.setString(3, us.getUsuario());
            ps.setString(4, us.getClave());

            
            int dat = ps.executeUpdate();
            
            if (dat>0) {               
                respuesta=1;               
            }
                     
        }
        catch (SQLException ex) {           
            JOptionPane.showMessageDialog(null,"Error al insertar"+ ex);           
        }  
    return respuesta; 
        
    }
    
    public boolean modificarcontraseña(Usuarios usu){
        
        boolean dat=false;
        
          try {
                
            
            ps=cnn.prepareStatement("UPDATE usuarios SET usu_user= ?, contraseña=? WHERE doc_user=  ?  ");
                
                ps.setString(1, usu.getUsuario());
                ps.setString(2, usu.getClave());
                ps.setString(3, usu.getCedula());
            
            int x=ps.executeUpdate();           
            if (x>0) {               
                dat=true;
            }           
        }   
        catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Error al modificarcliente"+ex);           
        }   
        return dat;      
    }
    
    public boolean modificarcontraseña2(Usuarios usu){
        
        boolean dat=false;
        
          try {
                
            ps=cnn.prepareStatement("UPDATE usuarios SET contraseña = ? WHERE doc_user = ? and usu_user = ? ");
                
                ps.setString(1, usu.getClave());
                ps.setString(2, usu.getCedula());
                ps.setString(3, usu.getUsuario());
            
            int x=ps.executeUpdate();           
            if (x>0) {               
                dat=true;
            }           
        }   
        catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Error al actualizar contraseña"+ex);           
        }   
        return dat;      
    }
    
    public boolean editar_usuarios(Usuarios ser){
        
        boolean dat=false;
        
        try {
            
            ps=cnn.prepareStatement("UPDATE usuarios SET  nom_user='"+ser.getNombre()+"' WHERE doc_user='"+ser.getCedula()+"'");
            int x=ps.executeUpdate();           
            if (x>0) {                
                dat=true;
            }           
        }  
        catch (SQLException ex) {   
            JOptionPane.showMessageDialog(null, "Error al modificar usuario"+ex);    
        }
        return dat;     
    }
    
    public boolean eliminarusuario(Usuarios cl){
        
        boolean dat=false;
        
        try {
            
            ps=cnn.prepareStatement("DELETE FROM usuarios WHERE usuarios.doc_user='"+cl.getCedula()+"' ");
            int x=ps.executeUpdate();
            
            if (x>0) {
                
                dat=true;

            }
            
        } 
        
        catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Error al eliminar Clientes"+ex);
            
        }
    
        return dat;
        
    }
    
}
