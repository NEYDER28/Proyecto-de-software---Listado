package Modelo;

public class Usuarios {
    
    private String cedula;
    private String nombre;
    private String usuario;
    private String clave;

    public Usuarios(String cedula, String usuario, String clave) {
        this.cedula = cedula;
        this.usuario = usuario;
        this.clave = clave;
    }

    public Usuarios(String cedula, String nombre) {
        this.cedula = cedula;
        this.nombre = nombre;
    }

    public Usuarios(String cedula, String nombre, String usuario, String clave) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.usuario = usuario;
        this.clave = clave;
    }

    public Usuarios() {
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }
  
}
