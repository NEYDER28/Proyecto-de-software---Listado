package Modelo;

import Conexion.conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Modelo_Login {
    
    conexion con=new conexion();
    Connection cnn=con.conexionbd();
    PreparedStatement ps=null;
    ResultSet rs=null;
    
    public ArrayList<Login2> login (Login2 log){
        ArrayList<Login2> lista=new ArrayList<>();
      
        try {
            
            ps=cnn.prepareStatement("select doc_user, nom_user, usu_user, contraseña, from usuarios where usu_user ='"+log.getUsuario()+"' AND contraseña='"+log.getClave()+"'");
            rs=ps.executeQuery();
            
            while (rs.next()){
            
                Login2 logi=new Login2(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
                lista.add(logi);
                
            }
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, ex);
            
        }
        
    return lista;
       
   }
}
