package Modelo;

import Conexion.conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Modelo_Cursos {
    
    conexion con=new conexion();
    Connection cnn=con.conexionbd();
    PreparedStatement ps=null;
    ResultSet rs=null;
    
    public ArrayList<Cursos> consultarCursos(){
        ArrayList<Cursos> lista=new ArrayList<>();
      
        try {
            
            ps=cnn.prepareStatement("SELECT * FROM cursos");
            rs=ps.executeQuery();
            
            while (rs.next()){
            
                Cursos cli=new Cursos(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
                lista.add(cli);
                
            }
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, ex);
            
        }
        
    return lista;
       
   }
    
    public boolean insertarCursos(Cursos se){
        
        boolean x=false;
        
        try {  
            ps=cnn.prepareStatement("INSERT INTO cursos VALUES(?,?,?,?)");
            ps.setString(1, se.getCodigo());
            ps.setString(2, se.getGrupo());
            ps.setString(3, se.getNombre());
            ps.setString(4, se.getDocumento());
            
            int dat = ps.executeUpdate();
            
            if (dat>0) {             
                x=true;             
            }       
        }       
        catch (SQLException ex) {          
            JOptionPane.showMessageDialog(null,"Error al insertar"+ ex);           
        }  
    return x;  
    }
    
    public boolean editar_Cursos(Cursos ser){
        
        boolean dat=false;
        
        try {
            
            ps=cnn.prepareStatement("UPDATE cursos SET materia = '"+ser.getNombre()+"', grupo  = '"+ser.getGrupo()+"' WHERE id_curso='"+ser.getCodigo()+"'");
            int x=ps.executeUpdate();           
            if (x>0) {                
                dat=true;
            }           
        }  
        catch (SQLException ex) {   
            JOptionPane.showMessageDialog(null, "Error al modificar Categoria"+ex);    
        }
        return dat;     
    }
    
    public boolean eliminar_Grupos(Cursos ser){
        
        boolean dat=false;
        
        try {
            
            ps=cnn.prepareStatement("DELETE FROM cursos WHERE id_curso = '"+ser.getCodigo()+"'");
            int x=ps.executeUpdate();           
            if (x>0) {                
                dat=true;
            }           
        }  
        catch (SQLException ex) {   
            JOptionPane.showMessageDialog(null, "Error al eliminar Categoria"+ex);    
        }
        return dat;     
    }
    
}
