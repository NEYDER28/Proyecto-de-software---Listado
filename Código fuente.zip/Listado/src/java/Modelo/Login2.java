package Modelo;

public class Login2 {
    
    private String cedula;
    private String nombre;
    private String usuario;
    private String clave;

    public Login2(String usuario, String clave) {
        this.usuario = usuario;
        this.clave = clave;
    }

    public Login2() {
    }
    
    public Login2(String cedula, String nombre, String usuario, String clave) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.usuario = usuario;
        this.clave = clave;

    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }  
}
