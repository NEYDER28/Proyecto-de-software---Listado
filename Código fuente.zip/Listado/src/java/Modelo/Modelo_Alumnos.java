package Modelo;

import Conexion.conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Modelo_Alumnos {
    
    conexion con=new conexion();
    Connection cnn=con.conexionbd();
    PreparedStatement ps=null;
    ResultSet rs=null;
    
    
    
    public ArrayList<Alumnos> consultarAlumnos() {
        ArrayList<Alumnos> lista=new ArrayList<>();
              
        try {
            
            ps=cnn.prepareStatement("SELECT * FROM alumnos");
            rs=ps.executeQuery();
                            
            while (rs.next()){
            
                Alumnos cli=new Alumnos(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10));
                lista.add(cli);
                
            }            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, ex);           
       }       
    return lista;
       
   }
    
        public ArrayList<Cursos> consultarCurso() {
        ArrayList<Cursos> lista=new ArrayList<>();
              
        try {
            
            ps=cnn.prepareStatement("SELECT * FROM cursos");
            rs=ps.executeQuery();
                            
            while (rs.next()){
            
                Cursos cli=new Cursos(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
                lista.add(cli);
                
            }            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, ex);           
       }       
    return lista;  
   }
    
    public boolean insertarAlumnos(Alumnos se){
        
        boolean x=false;
        
        try {  
            ps=cnn.prepareStatement("INSERT INTO alumnos VALUES(?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, se.getId());
            ps.setString(2, se.getDocumento());
            ps.setString(3, se.getApellido());
            ps.setString(4, se.getNombre());
            ps.setString(5, se.getFecha());
            ps.setString(6, se.getGenero());
            ps.setString(7, se.getCorreo());
            ps.setString(8, se.getCelular());
            ps.setString(9, se.getComentario());
            ps.setString(10, se.getId_curso());
            
            int dat = ps.executeUpdate();
            
            if (dat>0) {             
                x=true;             
            }       
        }       
        catch (SQLException ex) {          
            JOptionPane.showMessageDialog(null,"Error al insertar"+ ex);           
        }  
    return x;  
    }
    
    public boolean insertar_Lista(Lista se){
        
        boolean x=false;
        
        try {  
            ps=cnn.prepareStatement("INSERT INTO listas VALUES(?,?,?,?)");
            ps.setString(1, se.getId_lista());
            ps.setString(2, se.getFecha());
            ps.setString(3, se.getAsistencia());
            ps.setString(4, se.getId_alumno());

            
            int dat = ps.executeUpdate();
            
            if (dat>0) {             
                x=true;             
            }       
        }       
        catch (SQLException ex) {          
            JOptionPane.showMessageDialog(null,"Error al insertar"+ ex);           
        }  
    return x;  
    }
    
    public boolean editar_Alumnos(Alumnos ser){
        
        boolean dat=false;
        
        try {
            
            ps=cnn.prepareStatement("UPDATE alumnos SET doc_alumno = '"+ser.getDocumento()+"', apellido  = '"+ser.getApellido()+"' , nombre  = '"+ser.getNombre()+"', fecha  = '"+ser.getFecha()+"', genero  = '"+ser.getGenero()+"', correo = '"+ser.getCorreo()+"', celular  = '"+ser.getCelular()+"', comentario  = '"+ser.getComentario()+"', id_curso = '"+ser.getId_curso()+"' WHERE id_alumno='"+ser.getId()+"'");
            int x=ps.executeUpdate();           
            if (x>0) {                
                dat=true;
            }           
        }  
        catch (SQLException ex) {   
            JOptionPane.showMessageDialog(null, "Error al modificar Alumnos"+ex);    
        }
        return dat;     
    }
    
    public boolean eliminar_Alumnos(Alumnos ser){
        
        boolean dat=false;
        
        try {
            
            ps=cnn.prepareStatement("DELETE FROM alumnos WHERE id_alumno = '"+ser.getId()+"'");
            int x=ps.executeUpdate();           
            if (x>0) {                
                dat=true;
            }           
        }  
        catch (SQLException ex) {   
            JOptionPane.showMessageDialog(null, "Error al eliminar Categoria"+ex);    
        }
        return dat;     
    }
    
}
