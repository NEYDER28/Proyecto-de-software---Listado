package Modelo;

public class Cursos {
    
    private String codigo;
    private String grupo;
    private String nombre;
    private String documento;

    public Cursos() {
    }

    public Cursos(String codigo, String grupo, String nombre, String documento) {
        this.codigo = codigo;
        this.grupo = grupo;
        this.nombre = nombre;
        this.documento = documento;
    }
    
    public Cursos(String codigo) {
        this.codigo = codigo;
    }
    
    public Cursos(String grupo, String nombre, String documento) {
        this.grupo = grupo;
        this.nombre = nombre;
        this.documento = documento;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
        public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
        public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }
    
    
}
