package Modelo;
public class Alumnos {
    
    private String id;
    private String documento;
    private String apellido;
    private String nombre;
    private String fecha;
    private String genero;
    private String correo;
    private String celular;
    private String comentario;
    private String id_curso;
    private String fecha_ini;
    private String fecha_fin;
    private String tipo;
    private String cantidad;
    

    public Alumnos() {
    }
    
    public Alumnos(String id, String documento, String apellido, String nombre, String fecha, String genero, String correo, String celular, String comentario, String id_curso) {
        this.id = id;
        this.documento = documento;
        this.apellido = apellido;
        this.nombre = nombre;
        this.fecha = fecha;
        this.genero = genero;
        this.correo = correo;
        this.celular = celular;
        this.comentario = comentario;
        this.id_curso = id_curso;
    }
    
    public Alumnos(String tipo, String cantidad, String nombre, String apellido) {
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.nombre = nombre;
        this.apellido = apellido;
    }
    
    public Alumnos(String genero, String cantidad) {
        this.genero = genero;
        this.cantidad = cantidad;
    }
              
    public Alumnos(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    public String getDocumento() {
        return documento;
    }

    public void setDocuemnto(String documento) {
        this.documento = documento;
    }
    
        public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
        public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }
    
    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }
    
    public String getId_curso() {
        return id_curso;
    }

    public void setId_curso(String id_curso) {
        this.id_curso = id_curso;
    }
    
    public String getFecha_ini() {
        return fecha_ini;
    }

    public void setFecha_ini(String fecha_ini) {
        this.fecha_ini = fecha_ini;
    }
    
    public String getFecha_fin() {
        return fecha_ini;
    }

    public void setFecha_fin(String fecha_fin) {
        this.fecha_fin = fecha_fin;
    }
    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad (String cantidad) {
        this.cantidad = cantidad;
    }
}
